package example.vehiclemcp

import android.app.Activity
import android.os.Bundle
import android.text.InputType
import android.view.WindowManager
import android.widget.*
import kotlinx.coroutines.*

/** AVD용 수동 점검 화면. 토큰은 메모리에만 두고 화면을 떠나면 통신과 SDK를 정리한다. */
class MainActivity : Activity() {
    private lateinit var sdkStatus: TextView
    private lateinit var bridgeStatus: TextView
    private lateinit var resultView: TextView
    private lateinit var token: EditText
    private lateinit var bridgeButton: Button
    private var provider: PleosNavigationProvider? = null
    private var scope: CoroutineScope? = null
    private var bridgeJob: Job? = null
    private var readJob: Job? = null
    private val sdkEvents = ArrayDeque<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val density = resources.displayMetrics.density
            setPadding((28 * density).toInt(), (20 * density).toInt(), (28 * density).toInt(), (20 * density).toInt())
        }
        fun label(text: String, size: Float = 18f): TextView = TextView(this).apply {
            this.text = text; textSize = size; setPadding(0, 10, 0, 10); layout.addView(this)
        }
        label(getString(R.string.app_title), 24f)
        label(getString(R.string.app_description))
        sdkStatus = label(getString(R.string.sdk_waiting))
        val readButton = Button(this).apply { text = getString(R.string.read_navigation) }
        layout.addView(readButton)
        resultView = label(getString(R.string.no_result))
        label(getString(R.string.bridge_description))
        token = EditText(this).apply {
            hint = getString(R.string.bridge_token_hint)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            isSaveEnabled = false
            setSingleLine(true)
        }
        layout.addView(token)
        bridgeButton = Button(this).apply { text = getString(R.string.start_bridge) }
        layout.addView(bridgeButton)
        bridgeStatus = label(getString(R.string.bridge_stopped))
        setContentView(ScrollView(this).apply { addView(layout) })

        readButton.setOnClickListener {
            if (bridgeJob?.isActive == true) {
                resultView.text = getString(R.string.stop_bridge_before_read)
            } else if (readJob?.isActive != true) {
                readJob = scope?.launch {
                    resultView.text = getString(R.string.sdk_reading)
                    val result = provider?.readSnapshot() ?: return@launch
                    resultView.text = result.toString(2)
                }
            }
        }
        bridgeButton.setOnClickListener {
            if (bridgeJob?.isActive == true) {
                bridgeJob?.cancel(); bridgeButton.text = getString(R.string.start_bridge); bridgeStatus.text = getString(R.string.bridge_stopped)
            } else {
                val secret = token.text.toString().trim()
                if (secret.length < 32 || readJob?.isActive == true) {
                    bridgeStatus.text = getString(R.string.bridge_input_required)
                    return@setOnClickListener
                }
                val source = provider ?: return@setOnClickListener
                bridgeJob = scope?.launch {
                    bridgeButton.text = getString(R.string.stop_bridge)
                    bridgeStatus.text = getString(R.string.waiting_for_command)
                    try {
                        VehicleBridgeLoop("http://127.0.0.1:8000", secret, NavigationProvider {
                            source.readSnapshot().also { resultView.text = it.toString(2) }
                        }) { message ->
                            runOnUiThread { bridgeStatus.text = message }
                        }.run()
                    } finally {
                        bridgeButton.text = getString(R.string.start_bridge)
                    }
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        val session = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
        scope = session
        sdkEvents.clear()
        provider = PleosNavigationProvider(this) { message ->
            if (session.isActive) {
                // 토큰/좌표 없이 최근 SDK 상태를 남겨 화면과 API의 불일치를 진단한다.
                sdkEvents.addLast(message)
                if (sdkEvents.size > 8) sdkEvents.removeFirst()
                sdkStatus.text = sdkEvents.joinToString("\n")
            }
        }.also { it.start() }
    }

    override fun onStop() {
        // 화면이 보이지 않으면 차량 정보 조회와 네트워크 루프를 계속 실행하지 않는다.
        scope?.cancel(); scope = null
        provider?.close(); provider = null
        bridgeJob = null; readJob = null
        token.text.clear()
        resultView.text = getString(R.string.read_again)
        sdkStatus.text = getString(R.string.sdk_stopped)
        bridgeStatus.text = getString(R.string.bridge_stopped)
        bridgeButton.text = getString(R.string.start_bridge)
        super.onStop()
    }
}
