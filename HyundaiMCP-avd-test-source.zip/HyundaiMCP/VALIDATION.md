# AVD test app verification — 2026-10-27

- Android debug APK built with Gradle 8.9, AGP 8.7.3, Kotlin 1.9.25, JDK 21 and Android SDK 34.
- Official Maven dependency: `ai.pleos.playground:NaviHelper:3.0.5` (`navi-data:3.0.4`).
- SDK callback signatures and destination fields/units checked against official source JARs.
- `:app:testDebugUnitTest`: 6 passed, 0 failed, 0 skipped. Covers result mapping/units,
  invalid data, failure fields, Bridge request IDs, Bearer authentication and wrong server mode.
- HTTP Bridge tests use a local MockWebServer, not a Pleos AVD or a live Python server.
- `:app:assembleDebug` and `:app:lintDebug` passed; APK signature verified with apksigner.
- Python regression suite: 12 passed; `pip check`: no broken requirements.
- AVD installation, Navi Service connection, SDK permission grants and SDK-to-Python end-to-end
  execution: NOT executed here; follow `android/README.md` on the PC hosting the AVD.
- Live GPT API and physical vehicle behavior: NOT verified.
- `observed_at` is callback receipt time; SDK source data age cannot be independently verified.

## Previous Python-only baseline

# Verification — 2026-10-27

- Python 3.12.14; official MCP Python SDK 1.30.0.
- `python -m pytest -q`: 12 passed.
- Actual local HTTP MCP initialization, tool discovery, tool calls and Bridge round trips tested.
- Authentication separation, unsupported tools, no destination, SDK error, unsupported data,
  stale/future data, invalid negative values, timeout, duplicate results and concurrent correlation tested.
- GPT host tested with fake model responses and a real local MCP server; no paid API request.
- `pip check`: no broken requirements.
- Pleos SDK/Emulator, Android Kotlin compilation, real GPT API, ChatGPT UI connectors,
  public deployment and physical vehicle controls: NOT verified / NOT included.
