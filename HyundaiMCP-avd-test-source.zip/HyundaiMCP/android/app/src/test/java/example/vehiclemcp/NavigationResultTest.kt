package example.vehiclemcp

import java.time.Instant
import org.junit.Assert.*
import org.junit.Test

class NavigationResultTest {
    @Test fun destinationFieldsPreserveSdkUnitsAndObservationTime() {
        val instant = Instant.parse("2026-10-27T01:00:00Z")
        val result = NavigationResult("ok", instant, "서울역", 12300, 1080).toJson()
        assertEquals("pleos_sdk", result.getString("source"))
        assertEquals("ok", result.getString("status"))
        assertEquals("서울역", result.getString("destination_name"))
        assertEquals(12300, result.getInt("remaining_distance_m"))
        assertEquals(1080, result.getInt("remaining_duration_s"))
        assertEquals(instant.toString(), result.getString("observed_at"))
    }
    @Test fun failuresNeverContainNavigationValues() {
        for (status in listOf("no_destination", "sdk_error", "unsupported")) {
            val result = NavigationResult(status, name = "old", distanceMeters = 123, durationSeconds = 10).toJson()
            assertEquals(status, result.getString("status"))
            assertFalse(result.has("destination_name"))
            assertFalse(result.has("remaining_distance_m"))
            assertFalse(result.has("remaining_duration_s"))
        }
    }
    @Test fun invalidSuccessBecomesErrorInsteadOfInventedValues() {
        for (value in listOf(
            NavigationResult("ok"), NavigationResult("ok", name = " ", distanceMeters = 1, durationSeconds = 2),
            NavigationResult("ok", name = "서울역", distanceMeters = -1, durationSeconds = 2),
            NavigationResult("ok", name = "서울역", distanceMeters = 1, durationSeconds = -2),
            NavigationResult("ok", name = "x".repeat(201), distanceMeters = 1, durationSeconds = 2),
        )) {
            val result = value.toJson()
            assertEquals("sdk_error", result.getString("status"))
            assertFalse(result.has("remaining_distance_m"))
        }
    }
    @Test fun zeroDistanceAndDurationAreValid() {
        assertEquals("ok", NavigationResult("ok", name = "도착지", distanceMeters = 0, durationSeconds = 0)
            .toJson().getString("status"))
    }
}
