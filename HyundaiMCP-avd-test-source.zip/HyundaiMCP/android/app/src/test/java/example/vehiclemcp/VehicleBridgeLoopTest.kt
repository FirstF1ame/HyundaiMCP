package example.vehiclemcp

import kotlinx.coroutines.*
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.TimeUnit

class VehicleBridgeLoopTest {
    @Test fun commandIdAndSdkResultReachCorrectEndpointWithBridgeToken() = runBlocking {
        val server = MockWebServer()
        server.start()
        val token = "b".repeat(40)
        server.enqueue(MockResponse().setBody("""{"command_id":"test-command-id","tool":"get_navigation_info","arguments":{}}"""))
        server.enqueue(MockResponse().setBody("""{"accepted":true}"""))
        // 다음 poll을 401로 종료해 무한 루프 없이 인증 실패 처리도 확인한다.
        server.enqueue(MockResponse().setResponseCode(401))
        val messages = mutableListOf<String>()
        try {
            withTimeout(5_000) {
                withContext(Dispatchers.IO) {
                    VehicleBridgeLoop(server.url("/").toString().trimEnd('/'), token,
                        NavigationProvider {
                            NavigationResult("ok", name = "서울역", distanceMeters = 12300, durationSeconds = 1080).toJson()
                        }, messages::add).run()
                }
            }
            val poll = server.takeRequest(1, TimeUnit.SECONDS)!!
            val post = server.takeRequest(1, TimeUnit.SECONDS)!!
            assertEquals("/bridge/commands", poll.path)
            assertEquals("Bearer $token", poll.getHeader("Authorization"))
            assertEquals("/bridge/results", post.path)
            assertEquals("Bearer $token", post.getHeader("Authorization"))
            val payload = JSONObject(post.body.readUtf8())
            assertEquals("test-command-id", payload.getString("command_id"))
            assertEquals(12300, payload.getJSONObject("result").getInt("remaining_distance_m"))
            assertTrue(messages.any { it.contains("결과 전송 완료") })
        } finally { server.shutdown() }
    }

    @Test fun wrongServerModeStopsPollingAndReportsActionableError() = runBlocking {
        val server = MockWebServer()
        server.start()
        server.enqueue(MockResponse().setResponseCode(409))
        val messages = mutableListOf<String>()
        try {
            withTimeout(5_000) {
                withContext(Dispatchers.IO) {
                    VehicleBridgeLoop(server.url("/").toString().trimEnd('/'), "b".repeat(40),
                        NavigationProvider { error("must not query SDK") }, messages::add).run()
                }
            }
            assertEquals(1, server.requestCount)
            assertTrue(messages.single().contains("VEHICLE_MODE=bridge"))
        } finally { server.shutdown() }
    }
}
