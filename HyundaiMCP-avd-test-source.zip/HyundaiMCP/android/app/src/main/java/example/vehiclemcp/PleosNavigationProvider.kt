package example.vehiclemcp

import ai.pleos.playground.navi.constants.NaviErrorCode
import ai.pleos.playground.navi.data.DestinationInfo
import ai.pleos.playground.navi.data.RouteStateInfo
import ai.pleos.playground.navi.helper.NaviHelper
import ai.pleos.playground.navi.helper.listener.NaviHelperEventListener
import android.content.Context
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject

/**
 * NaviHelper 3.0.5 공식 소스의 공개 API만 사용한다.
 * SDK 콜백에는 요청 ID가 없으므로 조회를 직렬화한다. 콜백 시각은 차량 센서 측정 시각이 아니다.
 */
class PleosNavigationProvider(context: Context, private val report: (String) -> Unit) : NavigationProvider {
    private val helper = NaviHelper(context.applicationContext)
    private val callbacks = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val mutex = Mutex()
    private var connected = false
    private var closed = false
    private var routeReply: CompletableDeferred<Boolean>? = null
    private var destinationReply: CompletableDeferred<NavigationResult>? = null

    private val listener = object : NaviHelperEventListener {
        override fun onRouteStateInfo(routeStateInfo: RouteStateInfo) {
            callbacks.launch { routeReply?.complete(routeStateInfo.isRouting) }
        }
        override fun onDestinationInfo(destinationInfo: DestinationInfo) {
            // SDK 명세: name=목적지, remainDistance=미터, remainTime=초.
            val result = NavigationResult("ok", name = destinationInfo.name,
                distanceMeters = destinationInfo.remainDistance, durationSeconds = destinationInfo.remainTime)
            callbacks.launch { destinationReply?.complete(result) }
        }
        override fun onDestinationChanged() {
            callbacks.launch {
                report("목적지 변경 이벤트 수신 · 다시 조회하세요")
                val failure = IllegalStateException("Destination changed during query")
                routeReply?.completeExceptionally(failure)
                destinationReply?.completeExceptionally(failure)
            }
        }
        override fun onError(errorCode: NaviErrorCode) {
            callbacks.launch {
                // 원문 SDK 오류는 MCP에 보내지 않고 화면에 상태만 표시한다.
                report("SDK 오류 이벤트 · 권한 및 내비게이션 상태를 확인하세요")
                val failure = IllegalStateException("SDK error")
                routeReply?.completeExceptionally(failure)
                destinationReply?.completeExceptionally(failure)
            }
        }
    }

    fun start() {
        report("NaviHelper 연결 중…")
        try {
            helper.initialize(onConnected = {
                callbacks.launch {
                    if (!closed) {
                        connected = true
                        helper.addListener(listener)
                        report("NaviHelper 연결됨 · 목적지 조회 가능")
                    }
                }
            }, onFailed = {
                callbacks.launch { connected = false; report("SDK 연결 실패 · Pleos Navi Service 실행을 확인하세요") }
            })
        } catch (_: Exception) {
            report("SDK 초기화 실패 · SDK 서비스/권한을 확인하세요")
        }
    }

    override suspend fun readSnapshot(): JSONObject = withContext(Dispatchers.Main.immediate) {
        mutex.withLock {
            if (!connected || closed) return@withLock NavigationResult("sdk_error").toJson()
            try {
                // 경로 상태부터 확인한다. 목적지가 없는 상태를 임의의 빈 목적지 값으로 추론하지 않는다.
                withTimeout(6_000) {
                    routeReply = CompletableDeferred()
                    helper.getRouteStateInfo()
                    if (!routeReply!!.await()) return@withTimeout NavigationResult("no_destination").toJson()
                    destinationReply = CompletableDeferred()
                    helper.getDestinationInfo()
                    destinationReply!!.await().toJson()
                }
            } catch (_: TimeoutCancellationException) {
                report("SDK 응답 시간 초과 · 내비게이션 앱과 권한을 확인하세요")
                NavigationResult("sdk_error").toJson()
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (_: Exception) {
                report("SDK 조회 실패 · 권한 및 내비게이션 상태를 확인하세요")
                NavigationResult("sdk_error").toJson()
            } finally {
                routeReply?.cancel(); destinationReply?.cancel()
                routeReply = null; destinationReply = null
            }
        }
    }

    fun close() {
        closed = true
        connected = false
        callbacks.cancel()
        routeReply?.cancel(); destinationReply?.cancel()
        runCatching { helper.removeListener(listener) }
        runCatching { helper.release() }
    }
}
