package example.vehiclemcp

import java.time.Instant
import org.json.JSONObject

/** SDK 응답을 Python Bridge 계약으로 변환한다. 실제 값이 없으면 숫자를 만들지 않는다. */
data class NavigationResult(
    val status: String,
    val observedAt: Instant = Instant.now(),
    val name: String? = null,
    val distanceMeters: Int? = null,
    val durationSeconds: Int? = null,
) {
    fun toJson(): JSONObject {
        val valid = status == "ok" && !name.isNullOrBlank() && name.length <= 200 &&
            distanceMeters != null && distanceMeters >= 0 && durationSeconds != null && durationSeconds >= 0
        val result = JSONObject().put("source", "pleos_sdk")
            .put("status", if (status == "ok" && !valid) "sdk_error" else status)
            .put("observed_at", observedAt.toString())
        if (valid) {
            result.put("destination_name", name)
                .put("remaining_distance_m", distanceMeters)
                .put("remaining_duration_s", durationSeconds)
        }
        return result
    }
}
